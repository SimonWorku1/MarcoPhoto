import { useState } from 'react';
import { BubbleButton } from './components/BubbleButton';
import logo from 'figma:asset/bc1bc1c44f6ba6cb1fd8be782ee33922cc6339af.png';

type GameScreen = 'menu' | 'join-input' | 'lobby' | 'photo-select' | 'role-reveal';
type Role = 'Marco' | 'Reg';

export default function App() {
  const [screen, setScreen] = useState<GameScreen>('menu');
  const [roomCode, setRoomCode] = useState<string>('');
  const [inputCode, setInputCode] = useState<string>('');
  const [isHost, setIsHost] = useState(false);
  const [photosSelected, setPhotosSelected] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [role, setRole] = useState<Role | null>(null);

  const generateRoomCode = () => {
    // Generate a 6-character alphanumeric code
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const handleCreateRoom = () => {
    const code = generateRoomCode();
    setRoomCode(code);
    setIsHost(true);
    setScreen('lobby');
  };

  const handleJoinGame = () => {
    setScreen('join-input');
  };

  const handleJoinWithCode = () => {
    if (inputCode.trim()) {
      setRoomCode(inputCode.toUpperCase());
      setIsHost(false);
      setScreen('lobby');
    }
  };

  const handleStartGame = () => {
    setScreen('photo-select');
  };

  const handleSelectPhotos = () => {
    setPhotosSelected(true);
  };

  const handleReady = () => {
    setIsReady(true);
    // Simulate role assignment - randomly assign Marco or Reg
    // In a real multiplayer game, this would be coordinated across all players
    const assignedRole: Role = Math.random() < 0.25 ? 'Marco' : 'Reg';
    setRole(assignedRole);
    setScreen('role-reveal');
  };

  return (
    <div className="size-full flex items-center justify-center p-8">
      <div className="text-center">
        {screen === 'menu' && (
          <div className="space-y-8">
            <img src={logo} alt="Marco Photo" className="w-full max-w-4xl mx-auto mb-8" />
            <p className="text-2xl mb-8">Get ready for a fun game!</p>
            <div className="flex flex-col gap-4 items-center">
              <BubbleButton onClick={handleCreateRoom}>
                Create Room
              </BubbleButton>
              <BubbleButton onClick={handleJoinGame}>
                Join Game
              </BubbleButton>
            </div>
          </div>
        )}

        {screen === 'join-input' && (
          <div className="space-y-8">
            <h1 className="text-5xl mb-4">Join a Room</h1>
            <p className="text-xl mb-8">Enter the room code:</p>
            <input
              type="text"
              value={inputCode}
              onChange={(e) => setInputCode(e.target.value)}
              className="border-2 border-gray-300 p-2 w-64 mx-auto"
            />
            <BubbleButton onClick={handleJoinWithCode}>
              Join
            </BubbleButton>
          </div>
        )}

        {screen === 'lobby' && (
          <div className="space-y-8">
            <h1 className="text-5xl mb-4">Game Lobby</h1>
            <div className="bg-white rounded-3xl p-8 mb-8 shadow-lg">
              <p className="text-xl mb-2">Room Code:</p>
              <p className="text-6xl font-bold text-blue-500">{roomCode}</p>
            </div>
            <p className="text-xl mb-8">Waiting for players...</p>
            {isHost && (
              <BubbleButton onClick={handleStartGame}>
                Start Game
              </BubbleButton>
            )}
          </div>
        )}

        {screen === 'photo-select' && (
          <div className="space-y-8">
            <h1 className="text-5xl mb-4">Select Your Photos</h1>
            <p className="text-xl mb-8">
              {photosSelected 
                ? "Photos selected! Click Ready when you're all set." 
                : "Choose your photos for the game"}
            </p>
            <div className="flex flex-col gap-4 items-center">
              {!photosSelected && (
                <BubbleButton onClick={handleSelectPhotos}>
                  Select Photos
                </BubbleButton>
              )}
              {photosSelected && (
                <BubbleButton onClick={handleReady}>
                  Ready
                </BubbleButton>
              )}
            </div>
          </div>
        )}

        {screen === 'role-reveal' && role && (
          <div className="space-y-8">
            <h1 className="text-6xl mb-4">Your Role</h1>
            <div className={`text-8xl p-12 rounded-3xl shadow-2xl ${
              role === 'Marco' 
                ? 'bg-blue-500 text-white' 
                : 'bg-white text-blue-500 border-4 border-blue-500'
            }`}>
              {role === 'Marco' ? '🏊 Marco 🏊' : '🧍 Reg 🧍'}
            </div>
            <p className="text-3xl mt-8">
              {role === 'Marco' 
                ? "You're the Marco! Time to hunt!" 
                : "You're a Reg. Stay hidden!"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}